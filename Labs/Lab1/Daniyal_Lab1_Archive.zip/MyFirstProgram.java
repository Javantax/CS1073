/**
	@author Daniyal Khan 3765942
**/

public class MyFirstProgram {
	public static void main (String[] args) {
		System.out.println("Hello World");
		}
	} //MyFirstProgram
